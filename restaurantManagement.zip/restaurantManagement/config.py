DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = "root12345"
DB_NAME = "fdbproject"

UPI_ID = "restaurant@upi"
